def hello_world(request):
    return 'Hello, World from Google Cloud Functions but with Python!'