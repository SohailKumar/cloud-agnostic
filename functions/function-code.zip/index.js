exports.helloWorld = (req, res) => {
    res.send('Hello, World from Google Cloud Functions!');
};